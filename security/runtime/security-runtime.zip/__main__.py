import os,sys,fcntl,hashlib
try:
    fd=int(os.environ['ZOER_SECURITY_ARCHIVE_FD'])
    expected=os.environ['ZOER_SECURITY_EXPECTED_SHA256']
    required=fcntl.F_SEAL_WRITE|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_GROW|fcntl.F_SEAL_SEAL
    if sys.argv[0]!='/proc/self/fd/'+str(fd) or fcntl.fcntl(fd,fcntl.F_GET_SEALS)&required!=required:
        raise ValueError('Unsealed scanner archive')
    with open(sys.argv[0],'rb') as stream: data=stream.read(8*1024*1024+1)
    if len(data)>8*1024*1024 or hashlib.sha256(data).hexdigest()!=expected:
        raise ValueError('Scanner archive digest mismatch')
except (KeyError,ValueError,OSError,AttributeError):
    raise SystemExit('Run this packaged protocol through the approved sealed host bootstrap')
from zoer_wp_security.runtime import main
raise SystemExit(main())
