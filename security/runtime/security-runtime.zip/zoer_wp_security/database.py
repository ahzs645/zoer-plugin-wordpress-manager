"""Direct MySQL/MariaDB SELECTs. Never loads wp-config.php or any site PHP."""
import hashlib
import json
import re
import subprocess
import selectors
import time
from .model import Check, finding

IDENTIFIER = re.compile(r"^[A-Za-z0-9_$]+$")
SC = re.compile(r"SC_DB_BEGIN|SC_ADV_BEGIN|SC_CORE_BOOT|SCV:\d|SCOCV|_sc_fpc|__scf_|retadpu-ohce|sc_payload_persistent")
CONTENT = re.compile(r"<script\b|<iframe\b|\beval\s*\(|base64_decode\s*\(|document\.write\s*\(|window\.location", re.I)


def ident(value):
    if not isinstance(value, str) or not IDENTIFIER.fullmatch(value):
        raise ValueError("Unsupported SQL identifier")
    return "`" + value + "`"


class MysqlExecutor:
    def __init__(self, command, timeout=60):
        if not isinstance(command, list) or not command or not all(isinstance(a, str) for a in command):
            raise ValueError("MySQL transport must be an operator-supplied argument array")
        self.command, self.timeout = command, timeout

    def __call__(self, select):
        if not select.startswith("SELECT ") or ";" in select:
            raise ValueError("Only one internally generated SELECT is accepted")
        sql = "SET TRANSACTION READ ONLY; START TRANSACTION; " + select + "; COMMIT;\n"
        # Bound both streams while they arrive, rather than collecting an unbounded query result.
        process = subprocess.Popen(self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = bytearray(), bytearray()
        started = time.monotonic()
        try:
            process.stdin.write(sql.encode()); process.stdin.close()
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ, stdout)
                selector.register(process.stderr, selectors.EVENT_READ, stderr)
                while selector.get_map():
                    if time.monotonic() - started > self.timeout:
                        raise TimeoutError("MySQL query time limit exceeded")
                    for key, _ in selector.select(timeout=0.2):
                        chunk = key.fileobj.read1(65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        key.data.extend(chunk)
                        if len(stdout) > 8*1024*1024 or len(stderr) > 65536:
                            raise RuntimeError("MySQL output limit exceeded; coverage is incomplete")
            process.wait(timeout=max(0.1,self.timeout-(time.monotonic()-started)))
        finally:
            if process.poll() is None:
                process.kill(); process.wait()
            process.stdout.close(); process.stderr.close()
        if process.returncode:
            # Diagnostics may include passwords or SQL values; expose a digest, not raw stderr.
            raise RuntimeError("MySQL query failed (diagnostic SHA256 " + hashlib.sha256(stderr).hexdigest() + ")")
        rows = []
        for line in stdout.decode().splitlines():
            if line:
                rows.append(json.loads(bytes.fromhex(line).decode("utf-8")))
        return rows


def audit_database(execute, prefix, page_size=250, max_rows=100000, max_field_bytes=1048576):
    ident(prefix)
    if any(type(v) is not int or v <= 0 for v in (page_size, max_rows, max_field_bytes)):
        raise ValueError("Database limits must be positive integers")
    inventory = Check("database-inventory")
    content = Check("database-content")
    accounts = Check("database-administrators")
    triggers = Check("database-triggers")
    cron = Check("wordpress-cron")
    checks = [inventory, content, accounts, triggers, cron]
    try:
        columns = execute("SELECT HEX(JSON_ARRAY(TABLE_NAME,COLUMN_NAME,DATA_TYPE,COLUMN_KEY)) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME,ORDINAL_POSITION")
        tables = {}
        for table, column, dtype, key in columns:
            ident(table); ident(column)
            entry = tables.setdefault(table, {"text": [], "primary": []})
            if key == "PRI":
                entry["primary"].append(column)
            if dtype in {"char", "varchar", "tinytext", "text", "mediumtext", "longtext", "json"}:
                entry["text"].append(column)
        required = {prefix + x for x in ("options", "users", "usermeta", "posts")}
        if not required.issubset(tables):
            raise ValueError("Required WordPress tables are missing; verify the explicitly selected prefix")
        inventory.coverage = {"tables": tables, "tableCount": len(tables), "prefix": prefix}
        inventory.finish()
    except Exception as error:
        inventory.errors = [str(error)]; inventory.status = "error"
        return checks

    scopes, seen, limited = [], 0, False
    for table, spec in tables.items():
        if not spec["text"]:
            continue
        scope = {"table": table, "columns": spec["text"], "scannedRows": 0, "complete": False}
        scopes.append(scope)
        try:
            if not spec["primary"]:
                raise ValueError("Table has no primary key; stable pagination unavailable")
            count = execute(f"SELECT HEX(JSON_ARRAY(COUNT(*))) FROM {ident(table)}")[0][0]
            scope["expectedRows"] = count
            order = ",".join(ident(k) for k in spec["primary"])
            values = [f"CAST({ident(k)} AS CHAR)" for k in spec["primary"]]
            # Oversized fields are identified by their lengths; avoid silently scanning a prefix.
            for column in spec["text"]:
                c = ident(column)
                values += [f"OCTET_LENGTH(COALESCE({c},''))", f"IF(OCTET_LENGTH(COALESCE({c},''))<={max_field_bytes},HEX(COALESCE({c},'')),NULL)"]
            while scope["scannedRows"] < count:
                budget = min(page_size, max_rows - seen)
                if budget <= 0:
                    limited = True
                    break
                rows = execute(f"SELECT HEX(JSON_ARRAY({','.join(values)})) FROM {ident(table)} ORDER BY {order} LIMIT {budget} OFFSET {scope['scannedRows']}")
                if not rows:
                    raise RuntimeError("Rows disappeared during pagination")
                for row in rows:
                    keys = row[:len(spec["primary"])]
                    fields = row[len(spec["primary"]):]
                    for index, column in enumerate(spec["text"]):
                        length, encoded = fields[index*2:index*2+2]
                        location = {"table": table, "column": column, "primaryKey": dict(zip(spec["primary"], keys))}
                        if encoded is None:
                            content.errors.append({**location, "reason": "field-size-limit", "bytes": length})
                            continue
                        raw = bytes.fromhex(encoded)
                        text = raw.decode("utf-8", "replace")
                        markers = sorted({m.group() for m in SC.finditer(text)})
                        if markers:
                            content.findings.append(finding("sc-database-content-candidate", location, raw, markers=markers))
                        elif CONTENT.search(text):
                            content.findings.append(finding("embedded-script-review", location, raw))
                    scope["scannedRows"] += 1
                    seen += 1
                if len(rows) < budget and scope["scannedRows"] < count:
                    raise RuntimeError("Short page before expected row count")
            final_count = execute(f"SELECT HEX(JSON_ARRAY(COUNT(*))) FROM {ident(table)}")[0][0]
            scope["complete"] = scope["scannedRows"] == count == final_count
            if count != final_count:
                content.errors.append({"table": table, "reason": "row-count-changed"})
        except Exception as error:
            content.errors.append({"table": table, "reason": str(error)})
    content.coverage = {"scopes": scopes, "scannedRows": seen, "rowLimit": max_rows,
                        "fieldByteLimit": max_field_bytes, "truncated": limited,
                        "consistency": "Each query is read-only; live tables may change between queries. Not an atomic site snapshot."}
    content.finish(all(s["complete"] for s in scopes) and not limited)

    def query_check(check, sql, handler):
        try:
            rows = execute(sql)
            check.coverage = {"rows": len(rows), "limit": None}
            handler(rows)
            check.finish()
        except Exception as error:
            check.errors = [str(error)]; check.status = "error"

    def admin_rows(rows):
        admins = []
        for user_id, login, registered, caps in rows:
            if re.search(r's:13:"administrator";b:1;', caps):
                admins.append({"id": user_id, "login": login, "registered": registered})
                if re.search(r"_(?:[a-f0-9]{6})$", login):
                    accounts.findings.append(finding("administrator-name-review", f"user:{user_id}", login))
        accounts.coverage["administrators"] = admins
        accounts.coverage["authorizationVerified"] = False
        accounts.coverage["note"] = "Account names and quantities alone do not establish maliciousness"

    query_check(accounts, f"SELECT HEX(JSON_ARRAY(u.ID,u.user_login,u.user_registered,m.meta_value)) FROM {ident(prefix+'users')} u JOIN {ident(prefix+'usermeta')} m ON u.ID=m.user_id WHERE m.meta_key='{prefix}capabilities' ORDER BY u.ID", admin_rows)
    def trigger_rows(rows):
        for name, event, table, statement in rows:
            triggers.findings.append(finding("database-trigger-review", {"name": name, "event": event, "table": table}, statement))
    query_check(triggers, "SELECT HEX(JSON_ARRAY(TRIGGER_NAME,EVENT_MANIPULATION,EVENT_OBJECT_TABLE,ACTION_STATEMENT)) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() ORDER BY TRIGGER_NAME", trigger_rows)
    def cron_rows(rows):
        cron.coverage["options"] = [{"name": name, "bytes": len(value.encode()), "sha256": hashlib.sha256(value.encode()).hexdigest()} for name, value in rows]
        cron.coverage["note"] = "Serialized cron is inventoried without unserializing or executing; host cron and shared memory not checked"
        for name, value in rows:
            if SC.search(value):
                cron.findings.append(finding("sc-cron-candidate", name, value))
    query_check(cron, f"SELECT HEX(JSON_ARRAY(option_name,option_value)) FROM {ident(prefix+'options')} WHERE option_name IN ('cron','active_plugins','auto_update_plugins','auto_update_themes') ORDER BY option_name", cron_rows)
    return checks
