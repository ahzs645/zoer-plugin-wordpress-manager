from dataclasses import dataclass, field, asdict
import hashlib
import json


@dataclass
class Check:
    name: str
    status: str = "not_checked"
    coverage: dict = field(default_factory=dict)
    findings: list = field(default_factory=list)
    errors: list = field(default_factory=list)

    def finish(self, complete=True):
        self.status = ("incomplete" if not complete or self.errors else
                       "findings" if self.findings else "no_findings")
        return self


def finding(rule, subject, data=b"", severity="review", **metadata):
    """Evidence hashes, never credentials or arbitrary source excerpts."""
    if isinstance(data, str):
        data = data.encode()
    return {"rule": rule, "subject": subject, "severity": severity,
            "sha256": hashlib.sha256(data).hexdigest(), **metadata}


def report(checks, **metadata):
    statuses = {c.status for c in checks}
    status = ("error" if "error" in statuses else "incomplete" if
              statuses & {"incomplete", "not_checked"} else
              "findings" if "findings" in statuses else "no_findings")
    return {"schemaVersion": 1, "status": status, "readOnly": True,
            "findingCount": sum(len(c.findings) for c in checks),
            "checks": [asdict(c) for c in checks], **metadata}


def private_json(path, value):
    import os
    # Refuse overwriting an existing report, including symlinks.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as out:
        json.dump(value, out, indent=2, ensure_ascii=True)
        out.write("\n")
