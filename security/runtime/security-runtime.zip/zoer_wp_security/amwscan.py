import hashlib
import json
from pathlib import Path
import subprocess
import os
import signal
import time
from .model import Check

PINNED_SHA256 = "a7fbc16c573a29f89bcc5d1c46308aa370638bef26f1ecbe71fc2d93a50b5210"


def normalize(payload, exit_code):
    check = Check("amwscan")
    if exit_code not in (0, 1) or not isinstance(payload, dict):
        check.status = "error"
        check.errors = ["Scanner failed or returned an invalid report"]
        return check
    coverage = payload.get("coverage")
    findings = payload.get("findings")
    if not isinstance(coverage, dict) or not isinstance(findings, list):
        check.status = "error"
        check.errors = ["Scanner report lacks structured coverage/findings"]
        return check
    check.coverage = coverage
    for item in findings:
        if not isinstance(item, dict):
            check.errors.append("Malformed finding")
            continue
        # Preserve identifiers and location; keep arbitrary excerpts in the private raw report only.
        check.findings.append({k: item[k] for k in ("id", "kind", "severity", "subject", "status") if k in item})
    errors = coverage.get("errors", [])
    if isinstance(errors, list):
        check.errors.extend(str(e) for e in errors)
    elif type(errors) is int and errors >= 0:
        if errors:
            check.errors.append(f"Engine reported {errors} coverage errors; inspect private raw report")
    else:
        check.errors.append("Malformed coverage error count")
    return check.finish(coverage.get("complete") is True and not coverage.get("skipped"))


def run(root, scanner, output_dir, php="php", timeout=900):
    check = Check("amwscan")
    root, scanner, output_dir = map(lambda p: Path(p).resolve(), (root, scanner, output_dir))
    if output_dir == root or root in output_dir.parents:
        raise ValueError("Scanner output must be outside the snapshot")
    if hashlib.sha256(scanner.read_bytes()).hexdigest() != PINNED_SHA256:
        check.status = "error"
        check.errors = ["Scanner digest differs from reviewed AMWScan 0.21.15; review/pin an upgrade first"]
        return check
    output_dir.mkdir(mode=0o700, parents=True, exist_ok=False)
    report = output_dir / "amwscan.json"
    if report.exists():
        raise ValueError("Use a new output directory per scan")
    args = [php, '-d', 'auto_prepend_file=', '-d', 'auto_append_file=', str(scanner), str(root), "--lite", "--report-only", "--silent", "--jobs=1",
            "--scan-archives", "--max-filesize=5MB", "--disable-checksum", "--disable-definitions-update",
            "--disable-cache", "--report-format=json", f"--path-report={report}",
            f"--path-whitelist={output_dir / 'empty-whitelist.json'}",
            f"--path-definitions={output_dir / 'definitions'}", f"--path-deobfuscate={output_dir / 'deobfuscate'}"]
    process=None
    try:
        with (output_dir / "amwscan.log").open("xb") as log:
            log_path=output_dir/'amwscan.log'; log_path.chmod(0o600)
            process = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                       cwd=output_dir, start_new_session=True)
            deadline=time.monotonic()+timeout
            limits={log_path:1024*1024,report:32*1024*1024}
            failure=None
            while process.poll() is None:
                if time.monotonic()>deadline: failure='Scanner time limit exceeded'
                if any(path.exists() and path.stat().st_size>limit for path,limit in limits.items()):
                    failure='Scanner private output limit exceeded'
                if failure:
                    try: os.killpg(process.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                    process.wait(); break
                time.sleep(0.2)
            # A fast worker can exit between polls. Limit even completed output.
            for path,limit in limits.items():
                if path.exists() and path.stat().st_size>limit:
                    failure='Scanner private output limit exceeded'
                    with path.open('r+b') as stream: stream.truncate(limit)
                if path.exists(): path.chmod(0o600)
            if failure:
                check.status='error'; check.errors=[failure+'; coverage is incomplete']
                return check
        payload = json.loads(report.read_text())
        check = normalize(payload, process.returncode)
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        check.status = "error"
        check.errors = [type(error).__name__ + ": scanner report unavailable"]
    finally:
        if process is not None and process.poll() is None:
            try: os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError: pass
            process.wait()
    check.coverage["engine"] = {"version": "0.21.15", "sha256": PINNED_SHA256,
                               "checksumVerification": "not_checked", "remoteDefinitions": "disabled",
                               "database": "not_checked", "aiReview": "disabled",
                               "scope": "Engine default code extensions and bounded ZIPs, at most 5MB per file; independent byte-marker scan covers all extensions"}
    return check
