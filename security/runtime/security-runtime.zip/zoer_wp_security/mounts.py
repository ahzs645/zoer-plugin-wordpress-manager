"""Read-only mount boundaries for atomic directory recovery.

Linux rename can return EXDEV between two bind mounts of the same st_dev.
Use the kernel's exact directory-FD mount ID, and reject submounts inside a
selected directory instead of silently traversing/quarantining another mount.
"""
import os
from pathlib import Path
import re
import stat
import sys

MAX_MOUNTINFO = 2 * 1024 * 1024


def mount_identity(path):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        metadata = os.fstat(fd)
        if not stat.S_ISDIR(metadata.st_mode):
            raise ValueError('Atomic recovery requires ordinary directories')
        if sys.platform != 'linux':
            # Standalone operator tests on macOS do not have Linux bind mounts.
            return ('device', metadata.st_dev)
        with (Path('/proc/self/fdinfo') / str(fd)).open() as stream:
            data = stream.read(65537)
        match = re.search(r'^mnt_id:\s*(\d+)\s*$', data, re.M)
        if len(data) > 65536 or not match:
            raise ValueError('Linux recovery mount identity is unavailable')
        return ('linux-mount', int(match[1]))
    finally:
        os.close(fd)


def same_mount(first, second):
    return mount_identity(first) == mount_identity(second)


def _decode_mount_field(value):
    return re.sub(r'\\(040|011|012|134)', lambda m: chr(int(m[1], 8)), value)


def parse_mountpoints(data):
    if len(data.encode()) > MAX_MOUNTINFO:
        raise ValueError('Linux mount inventory exceeds supported limit')
    result = []
    for line in data.splitlines():
        fields = line.split()
        if len(fields) < 10 or not fields[0].isdigit() or not fields[1].isdigit() or '-' not in fields[6:]:
            raise ValueError('Linux mount inventory is malformed')
        name = _decode_mount_field(fields[4])
        point = Path(name)
        if not point.is_absolute() or '..' in point.parts:
            raise ValueError('Linux mount inventory has an invalid mount point')
        result.append(point)
    return result


def no_submounts(directory):
    if sys.platform != 'linux':
        return
    with Path('/proc/self/mountinfo').open() as stream:
        data = stream.read(MAX_MOUNTINFO + 1)
    directory = Path(directory).resolve()
    for point in parse_mountpoints(data):
        if point.is_relative_to(directory):
            raise ValueError('Selected plugin contains a mount boundary; atomic quarantine is unavailable')


def assert_atomic_directory_mount(source, destination):
    if not same_mount(source, destination):
        raise ValueError('Atomic quarantine requires the same exact filesystem mount for the plugin and private recovery directory')
    no_submounts(source)
