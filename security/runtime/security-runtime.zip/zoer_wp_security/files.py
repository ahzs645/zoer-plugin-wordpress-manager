import hashlib
import os
from pathlib import Path
import re
import stat
from .model import Check, finding

SC_MARKERS = re.compile(rb"SC_DB_BEGIN|SC_ADV_BEGIN|SC_CORE_BOOT|SCV:\d|SCOCV|_sc_fpc|__scf_|retadpu-ohce")
SC_PATH = re.compile(r"(^|/)(?:\.sc_[0-9a-f]+|\.wp-object-cache-[^/]+|echo-updater-x[^/]*|__PATH__)(/|$)", re.I)
EXECUTABLE = re.compile(r"\.(?:php\d*|phtml|phar)(?:\.|$)", re.I)
DROPINS = {"db.php", "object-cache.php", "advanced-cache.php", "sunrise.php", "maintenance.php"}


def inspect_files(root, max_size=32 * 1024 * 1024, max_total=512 * 1024 * 1024, max_files=100000):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Snapshot root must be a directory")
    check = Check("files-and-persistence")
    manifest, inventory, skipped = {}, [], []
    discovered = scanned = total = 0
    walk_errors = []
    for directory, dirs, names in os.walk(root, followlinks=False, onerror=walk_errors.append):
        for name in sorted(dirs + names):
            path = Path(directory) / name
            relative = path.relative_to(root).as_posix()
            try:
                metadata = path.lstat()
                if SC_PATH.search(relative):
                    check.findings.append(finding("sc-family-path-candidate", relative))
                if stat.S_ISLNK(metadata.st_mode):
                    skipped.append({"path": relative, "reason": "symlink"})
                    continue
                if stat.S_ISDIR(metadata.st_mode):
                    continue
                discovered += 1
                if not stat.S_ISREG(metadata.st_mode):
                    skipped.append({"path": relative, "reason": "special-file"})
                    continue
                if metadata.st_size > max_size or total + metadata.st_size > max_total or scanned >= max_files:
                    skipped.append({"path": relative, "reason": "resource-limit"})
                    continue
                # O_NOFOLLOW closes the most common symlink race. Operate on a private snapshot.
                fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
                with os.fdopen(fd, "rb") as stream:
                    before = os.fstat(stream.fileno())
                    data = stream.read(max_size + 1)
                    after = os.fstat(stream.fileno())
                if len(data) > max_size or (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
                    skipped.append({"path": relative, "reason": "changed-during-read"})
                    continue
                total += len(data)
                scanned += 1
                manifest[relative] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
                if relative.startswith("wp-content/mu-plugins/") or relative in {f"wp-content/{p}" for p in DROPINS}:
                    inventory.append({"path": relative, **manifest[relative]})
                    if not data and relative.startswith("wp-content/mu-plugins/"):
                        check.findings.append(finding("empty-mu-file-review", relative, data))
                markers = sorted({m.group().decode("ascii") for m in SC_MARKERS.finditer(data)})
                if markers:
                    check.findings.append(finding("sc-family-content-candidate", relative, data, markers=markers))
                if relative.startswith("wp-content/uploads/") and EXECUTABLE.search(relative):
                    check.findings.append(finding("executable-upload-review", relative, data))
            except OSError as error:
                skipped.append({"path": relative, "reason": type(error).__name__})
    check.errors = [type(e).__name__ for e in walk_errors]
    check.coverage = {"discovered": discovered, "scanned": scanned, "bytes": total,
                      "skipped": skipped, "allExtensions": True, "hiddenFiles": True,
                      "persistenceInventory": inventory,
                      "scope": "Snapshot files; host cron, running processes and shared memory are not included"}
    return check.finish(not skipped), manifest


def compare_manifests(before, after):
    return sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
