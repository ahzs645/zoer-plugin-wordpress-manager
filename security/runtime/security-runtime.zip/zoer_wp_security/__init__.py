"""Read-only WordPress security inspection, independent of WordPress bootstrap."""
__version__ = "0.2.2"
