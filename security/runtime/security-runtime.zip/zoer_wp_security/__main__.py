import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from . import __version__
from .amwscan import run
from .database import MysqlExecutor, audit_database
from .files import compare_manifests, inspect_files
from .integrity import core_checksums
from .model import Check, private_json, report


def main():
    parser = argparse.ArgumentParser(description="Inspect a private WordPress snapshot without executing WordPress")
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--amwscan", type=Path)
    parser.add_argument("--mysql-command-file", type=Path, help="Private JSON argv array for trusted mysql transport; never a shell expression")
    parser.add_argument("--prefix", default="wp_")
    parser.add_argument("--core-checksums", type=Path, help="JSON obtained independently from official api.wordpress.org for the installed version")
    args = parser.parse_args()
    root, out = args.snapshot.resolve(strict=True), args.output.resolve()
    if root == out or root in out.parents:
        parser.error("Output must be outside the snapshot")
    out.mkdir(mode=0o700, parents=True, exist_ok=False)
    files, before = inspect_files(root)
    checks = [files]
    private_json(out / "manifest.json", before)
    if args.amwscan:
        checks.append(run(root, args.amwscan, out / "engine"))
    else:
        checks.append(Check("amwscan"))
    if args.mysql_command_file:
        checks.extend(audit_database(MysqlExecutor(json.loads(args.mysql_command_file.read_text())), args.prefix))
    else:
        checks.append(Check("database"))
    after_check, after = inspect_files(root)
    consistency = Check("snapshot-consistency")
    changes = compare_manifests(before, after)
    consistency.coverage = {"changedFiles": changes}
    consistency.finish(not changes and after_check.status != "incomplete")
    checks += [consistency, core_checksums(root, json.loads(args.core_checksums.read_text())) if args.core_checksums else Check("wordpress-core-checksums"), Check("plugin-theme-checksums"), Check("host-persistence")]
    value = report(checks, version=__version__, generatedAt=datetime.now(timezone.utc).isoformat(),
                   note="Heuristic findings require review. No findings is not a guarantee of safety. No remediation is implemented.")
    private_json(out / "report.json", value)
    print(json.dumps({"status": value["status"], "findingCount": value["findingCount"], "report": str(out / 'report.json')}))
    return 2 if value["status"] in {"error", "incomplete"} else 1 if value["findingCount"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
