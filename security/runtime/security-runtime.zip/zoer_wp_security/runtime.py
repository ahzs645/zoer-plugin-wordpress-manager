"""Trusted DDEV tooling protocol. Inspected PHP is tokenized, never included.

Only the reviewed Zoer host supplies protocol arguments. The webroot and private
artifact root are constants, not caller-selected paths. Report-only scans are
separate from explicit remediation and performance commands.
"""
import base64
from dataclasses import asdict
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import uuid
import zipfile

from . import __version__
from .amwscan import PINNED_SHA256, run as run_engine
from .database import MysqlExecutor, audit_database
from .files import inspect_files, compare_manifests
from .integrity import core_checksums
from .model import Check, private_json, report

ROOT = Path('/var/www/html')
BASE = Path('/var/www/.zoer-security')
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 512 * 1024 * 1024
MAX_FILES = 100000
MIN_FREE = 1024 * 1024 * 1024
SITE_ID = re.compile(r'[A-Za-z0-9_-]{1,160}')
UUID = re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}')
EXCLUDE = {'.ddev', '.git', '.zoer-private'}
PHP_TOKENS = """if(!function_exists('token_get_all')){exit(88);} $p=$argv[1]; if(is_link($p)||filesize($p)>1048576){exit(2);} $r=[];
foreach(token_get_all(file_get_contents($p)) as $t){if(is_array($t)){
if(in_array($t[0],[T_WHITESPACE,T_COMMENT,T_DOC_COMMENT],true)){continue;}
$r[]=[token_name($t[0]),$t[1]];}else{$r[]=['symbol',$t];}}
echo json_encode($r,JSON_THROW_ON_ERROR);"""


def now():
    return datetime.now(timezone.utc).isoformat()


def private_dir(path):
    path = Path(path)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.is_symlink() or not path.is_dir():
        raise ValueError('Private artifact directory is unsafe')
    os.chmod(path, 0o700)
    return path


def private_write(path, value):
    """Atomic status update, without following caller-created symlinks."""
    path = Path(path)
    private_dir(path.parent)
    fd, tmp = tempfile.mkstemp(prefix='.status-', dir=path.parent)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w') as out:
            json.dump(value, out, ensure_ascii=True)
            out.flush(); os.fsync(out.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def job_dir(scan_id):
    if not isinstance(scan_id, str) or not UUID.fullmatch(scan_id):
        raise ValueError('Invalid scan identifier')
    path = BASE / 'jobs' / scan_id
    if path.is_symlink(): raise ValueError('Unsafe scan directory')
    return path


def load_payload(encoded):
    if not isinstance(encoded, str) or len(encoded) > 32768:
        raise ValueError('Protocol argument limit exceeded')
    value = json.loads(base64.b64decode(encoded, validate=True))
    if not isinstance(value, dict): raise ValueError('Protocol requires an object')
    return value


def sealed_archive_fd():
    try:
        fd=int(os.environ['ZOER_SECURITY_ARCHIVE_FD'])
        expected=os.environ['ZOER_SECURITY_EXPECTED_SHA256']
        required=fcntl.F_SEAL_WRITE|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_GROW|fcntl.F_SEAL_SEAL
        if fd<0 or fcntl.fcntl(fd,fcntl.F_GET_SEALS)&required!=required or not re.fullmatch(r'[a-f0-9]{64}',expected):
            raise ValueError('Scanner archive is not sealed')
        if sys.argv[0]!=f'/proc/self/fd/{fd}': raise ValueError('Scanner archive descriptor mismatch')
        return fd
    except (KeyError,AttributeError,OSError,ValueError):
        raise ValueError('Run this packaged protocol through the approved sealed host bootstrap') from None


def php_tokens(path):
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > 1048576:
        raise ValueError('Configuration tokenization limit exceeded')
    result = subprocess.run(['php', '-n', '-r', PHP_TOKENS, str(path)],
                            stdin=subprocess.DEVNULL, capture_output=True, timeout=15)
    if result.returncode==88:
        # DDEV installs tokenizer as a shared system extension. Keep php.ini and
        # auto_prepend_file disabled; load only this trusted tokenizer module.
        result=subprocess.run(['php','-n','-d','extension=tokenizer','-r',PHP_TOKENS,str(path)],
                              stdin=subprocess.DEVNULL,capture_output=True,timeout=15)
    if result.returncode or len(result.stdout) > 4*1048576:
        raise ValueError('Configuration tokenization failed')
    tokens = json.loads(result.stdout)
    if not isinstance(tokens, list): raise ValueError('Invalid PHP tokenizer response')
    return tokens


def literal(token):
    if token[0] != 'T_CONSTANT_ENCAPSED_STRING':
        raise ValueError('Only literal PHP configuration strings are supported')
    text = token[1]
    if text[0] == "'":
        return text[1:-1].replace("\\'", "'").replace('\\\\', '\\')
    # Escape processing and interpolation must not change values silently.
    if '\\' in text or '$' in text:
        raise ValueError('Unsupported escaped or interpolated configuration string')
    return text[1:-1]


def static_values(tokens, names, variables=()):
    result = {}
    depth = 0
    for i, token in enumerate(tokens):
        if token[1] == '{': depth += 1
        if token[1] == '}': depth -= 1
        if token[0] == 'T_STRING' and token[1].lower() == 'define' and i+2 < len(tokens):
            if tokens[i+1][1] != '(' or tokens[i+2][0] != 'T_CONSTANT_ENCAPSED_STRING':
                raise ValueError('Dynamic constant definition is unsupported')
            name = literal(tokens[i+2])
            if name not in names: continue
            if depth or (i and tokens[i-1][1] not in (';', '}') and tokens[i-1][0] != 'T_OPEN_TAG'):
                raise ValueError('Conditional configuration constants are unsupported')
            if name in result or i+5 >= len(tokens) or tokens[i+3][1] != ',' or tokens[i+5][1] != ')':
                raise ValueError('Ambiguous or dynamic configuration constant')
            result[name] = literal(tokens[i+4])
        if token[0] == 'T_VARIABLE' and token[1] in variables:
            name = token[1]
            if depth or (i and tokens[i-1][1] not in (';', '}') and tokens[i-1][0] != 'T_OPEN_TAG'):
                raise ValueError('Conditional configuration assignments are unsupported')
            if name in result or i+3 >= len(tokens) or tokens[i+1][1] != '=' or tokens[i+3][1] != ';':
                raise ValueError('Ambiguous or dynamic configuration assignment')
            result[name] = literal(tokens[i+2])
    return result


def read_configuration(root):
    """Refuse conditional/dynamic site configuration rather than guessing a DB."""
    tokens = php_tokens(Path(root) / 'wp-config.php')
    # Conditional control flow or indirect definitions make a literal guess unsafe.
    disallowed = {'T_ELSE','T_ELSEIF','T_SWITCH','T_FOR','T_FOREACH','T_WHILE','T_DO',
                  'T_FUNCTION','T_FN','T_CLASS','T_GOTO','T_EVAL','T_INCLUDE','T_INCLUDE_ONCE',
                  'T_REQUIRE','T_VARIABLE','T_NEW'}
    for i, (kind, value) in enumerate(tokens):
        if kind in disallowed and not (kind == 'T_VARIABLE' and value == '$table_prefix'):
            raise ValueError('Dynamic WordPress configuration is unsupported')
        if kind == 'T_STRING' and i+1 < len(tokens) and tokens[i+1][1]=='(' and value.lower() not in ('define','defined'):
            raise ValueError('Dynamic WordPress configuration calls are unsupported')
        if kind == 'T_REQUIRE_ONCE':
            # Permit only the conventional final bootstrap, never execute it.
            suffix=[item[1] for item in tokens[i:]]
            if suffix not in (["require_once","ABSPATH",".","'wp-settings.php'",";"],
                              ["require_once","ABSPATH",".",'"wp-settings.php"',";"]):
                raise ValueError('Dynamic WordPress bootstrap is unsupported')
    values = static_values(tokens, {'DB_NAME','DB_USER','DB_PASSWORD','DB_HOST','WPLANG'}, ('$table_prefix',))
    expected = {'DB_NAME':'db','DB_USER':'db','DB_PASSWORD':'db','DB_HOST':'db'}
    if any(values.get(k) != v for k,v in expected.items()):
        raise ValueError('Only the existing standard DDEV database is supported; no external database connection was attempted')
    prefix = values.get('$table_prefix')
    if not isinstance(prefix, str) or not re.fullmatch(r'[A-Za-z0-9_]{1,64}', prefix):
        raise ValueError('Unsupported WordPress table prefix')
    return {'prefix':prefix, 'locale': values.get('WPLANG') or 'en_US'}


def core_release(root):
    values = static_values(php_tokens(Path(root)/'wp-includes/version.php'), set(), ('$wp_version','$wp_local_package'))
    version = values.get('$wp_version')
    if not isinstance(version,str) or not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',version):
        raise ValueError('Official core checksums require a stable literal WordPress version')
    locale=values.get('$wp_local_package') or 'en_US'
    if not isinstance(locale,str) or not re.fullmatch(r'[a-z]{2,3}(?:_[A-Z]{2})?',locale):
        raise ValueError('Unsupported WordPress release package locale')
    return version,locale


def core_version(root):
    return core_release(root)[0]


def fetch_core_manifest(version, locale):
    if not re.fullmatch(r'[a-z]{2,3}(?:_[A-Z]{2})?', locale):
        raise ValueError('Unsupported checksum locale')
    url = 'https://api.wordpress.org/core/checksums/1.0/?' + urllib.parse.urlencode({'version':version,'locale':locale})
    with urllib.request.urlopen(url, timeout=30) as response:
        if urllib.parse.urlparse(response.url).hostname != 'api.wordpress.org':
            raise ValueError('Unexpected checksum source redirect')
        data = response.read(2*1048576+1)
    if len(data)>2*1048576: raise ValueError('Checksum manifest limit exceeded')
    value = json.loads(data)
    value['version'] = version
    value['provenance'] = {'url':url,'retrievedAt':now(),'sha256':hashlib.sha256(data).hexdigest(), 'version':version,'locale':locale}
    return value


def snapshot(root, target):
    """Bounded private copy; retain every ordinary hidden/code/media file."""
    root, target = Path(root), Path(target)
    if shutil.disk_usage(target.parent).free < MIN_FREE:
        raise ValueError('Insufficient private scan storage: at least 1 GiB free is required')
    target=private_dir(target)
    check = Check('snapshot-copy'); skipped=[]; manifest={}; total=0
    def walk_error(error): skipped.append({'reason':type(error).__name__})
    for directory, dirs, names in os.walk(root, followlinks=False, onerror=walk_error):
        dirs[:] = sorted(d for d in dirs if not (Path(directory)==root and d in EXCLUDE))
        for name in sorted(dirs + names):
            source = Path(directory)/name; relative=source.relative_to(root).as_posix()
            try:
                meta=source.lstat()
                if stat.S_ISDIR(meta.st_mode): continue
                if not stat.S_ISREG(meta.st_mode):
                    skipped.append({'path':relative,'reason':'symlink-or-special-file'}); continue
                if meta.st_size>MAX_FILE or total+meta.st_size>MAX_TOTAL or len(manifest)>=MAX_FILES:
                    skipped.append({'path':relative,'reason':'resource-limit'}); continue
                fd=open_root_file(root,relative)
                with os.fdopen(fd,'rb') as stream:
                    before=os.fstat(stream.fileno()); data=stream.read(MAX_FILE+1); after=os.fstat(stream.fileno())
                if len(data)>MAX_FILE or (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):
                    skipped.append({'path':relative,'reason':'changed-during-copy'}); continue
                destination=target/relative; private_dir(destination.parent)
                out=os.open(destination,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                with os.fdopen(out,'wb') as stream: stream.write(data)
                total+=len(data); manifest[relative]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
            except OSError as error: skipped.append({'path':relative,'reason':type(error).__name__})
    check.coverage={'copied':len(manifest),'bytes':total,'skipped':skipped,'excludedRootDirectories':sorted(EXCLUDE),
                    'atomic':False,'scope':'Bounded file copy; live writes can change between copied files'}
    return check.finish(not skipped),manifest


def open_root_file(root,relative):
    """Use directory descriptors so a swapped parent symlink cannot escape."""
    parts=Path(relative).parts
    if not parts or Path(relative).is_absolute() or any(part in ('.','..') for part in parts):
        raise ValueError('Invalid snapshot path')
    flags=os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)
    directory=os.open(root,flags|os.O_DIRECTORY)
    try:
        for part in parts[:-1]:
            next_directory=os.open(part,flags|os.O_DIRECTORY,dir_fd=directory)
            os.close(directory); directory=next_directory
        return os.open(parts[-1],flags,dir_fd=directory)
    finally: os.close(directory)


def materialize_vendor():
    archive=Path(sys.argv[0])
    if zipfile.is_zipfile(archive):
        digest=hashlib.sha256(archive.read_bytes()).hexdigest()
        destination=BASE/'runtimes'/digest/'vendor'
        if not destination.exists():
            private_dir(destination.parent)
            staging=Path(tempfile.mkdtemp(prefix='.vendor-',dir=destination.parent))
            try:
                with zipfile.ZipFile(archive) as bundle:
                    for item in bundle.infolist():
                        if not item.filename.startswith('vendor/') or item.is_dir(): continue
                        relative=Path(item.filename).relative_to('vendor')
                        if '..' in relative.parts or relative.is_absolute() or item.file_size>8*1048576:
                            raise ValueError('Invalid reviewed runtime resource')
                        path=staging/relative; private_dir(path.parent)
                        path.write_bytes(bundle.read(item)); path.chmod(0o600)
                try: staging.rename(destination)
                except FileExistsError: pass
            finally:
                if staging.exists(): shutil.rmtree(staging)
        return destination
    return Path(__file__).resolve().parents[1]/'vendor'


def tooling_metadata():
    source = Path(sys.argv[0])
    descriptor = {}
    if zipfile.is_zipfile(source):
        with zipfile.ZipFile(source) as bundle: descriptor=json.loads(bundle.read('runtime-descriptor.json'))
    cli_version='unknown'
    try:
        version_dir=private_dir(BASE/'version-check')
        config_path=version_dir/'wp-cli.yml'
        if not config_path.exists(): config_path.write_text('{}\n'); config_path.chmod(0o600)
        if config_path.is_symlink() or config_path.read_bytes()!=b'{}\n': raise ValueError('Unsafe CLI version configuration')
        environment={key:value for key,value in os.environ.items() if not key.startswith('WP_CLI_')}
        environment.update(WP_CLI_CONFIG_PATH='/dev/null',WP_CLI_PACKAGES_DIR=str(version_dir/'empty-packages'))
        result=subprocess.run(['wp','--skip-packages','cli','version'],cwd=version_dir,
                              env=environment,
                              stdin=subprocess.DEVNULL,capture_output=True,timeout=15)
        match=re.fullmatch(r'WP-CLI (\d+\.\d+\.\d+)\s*',result.stdout.decode())
        if result.returncode==0 and match: cli_version=match[1]
    except (OSError,subprocess.SubprocessError): pass
    engine=materialize_vendor()/'amwscan/scanner'
    actual=hashlib.sha256(engine.read_bytes()).hexdigest()
    cli_parts=tuple(map(int,cli_version.split('.'))) if re.fullmatch(r'\d+\.\d+\.\d+',cli_version) else ()
    compatible_cli=bool(cli_parts and (2,12,0)<=cli_parts<(3,0,0))
    from .remediation import quarantine_capability
    return {**quarantine_capability(ROOT,BASE),'available':actual==PINNED_SHA256,'controllerVersion':__version__,'runtimeVersion':__version__,
            'repositoryCommit':descriptor.get('sourceCommit'),
            'tools':[{'id':'controller','name':'Zoer WordPress Security','installedVersion':__version__, 'repositoryVersion':__version__, 'sourceUrl':'https://github.com/ahzs645/zoer-wordpress-security','updateStatus':'not-checked'},
                     {'id':'amwscan','name':'AMWScan','installedVersion':'0.21.15','repositoryVersion':'0.21.15','runtimeSha256':actual,'sourceUrl':'https://github.com/marcocesarato/PHP-Antimalware-Scanner','updateStatus':'not-checked'},
                     {'id':'amwscan-definitions','name':'Bundled AMWScan definitions','installedVersion':'2026.09.08.1','repositoryVersion':'2026.09.08.1','runtimeSha256':'efb72cb8073528546b3a8df91dae67a0f1f97d072feedac4a4df7f733b22bb76','sourceUrl':'https://github.com/marcocesarato/PHP-Antimalware-Scanner','updateStatus':'not-checked'},
                     {'id':'wp-cli','name':'WP-CLI','installedVersion':cli_version,'repositoryVersion':'2.12.0','sourceUrl':'https://github.com/wp-cli/wp-cli','updateStatus':'not-checked'},
                     {'id':'profile-command','name':'WP-CLI profile command','installedVersion':'2.1.5','repositoryVersion':'2.1.5','sourceUrl':'https://github.com/wp-cli/profile-command','updateStatus':'not-checked','compatibilityNote':'Pinned compatible command for WP-CLI 2.12; newer 3.0.0 requires WP-CLI 3.0.'}],
            'profilingAvailable':compatible_cli,'profilingSetupRequired':not (BASE/'performance/profile-command-2.1.5/installed.json').exists(),
            'profileModes':['stage','hook'],'profileQueriesReason':'Queries requires the newer profile command and a compatible WP-CLI upgrade; the pinned command supports stage and hook.'}


def status(scan_id):
    job=job_dir(scan_id)
    try: value=json.loads((job/'scan.json').read_text())
    except (FileNotFoundError,json.JSONDecodeError):
        return {'unavailable':True,'reason':'Scan artifacts are no longer available; the local runtime may have restarted','scanId':scan_id}
    if value.get('status')=='running':
        pid=value.get('pid')
        try:
            if type(pid) is not int: raise ProcessLookupError()
            os.kill(pid,0)
            identity=process_identity(pid)
            if identity['pidStartTicks']!=value.get('pidStartTicks') or identity['workerCommandSha256']!=value.get('workerCommandSha256'):
                raise ProcessLookupError()
        except ProcessLookupError:
            value.update(status='failed',phase='interrupted',completedAt=now(),error='Scan worker is no longer running; coverage is incomplete')
            private_write(job/'scan.json',value)
    if value.get('status')=='completed':
        try: value['report']=json.loads((job/'report.json').read_text())
        except (FileNotFoundError,json.JSONDecodeError):
            return {'unavailable':True,'reason':'Completed scan report is no longer available','scanId':scan_id}
    return {'scan':value}


def process_identity(pid):
    """Linux PID reuse cannot turn an unrelated process into a running scan."""
    try:
        fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
        command=(Path('/proc')/str(pid)/'cmdline').read_bytes()
        if fields[0]=='Z' or not command: raise ProcessLookupError()
        return {'pidStartTicks':fields[19],'workerCommandSha256':hashlib.sha256(command).hexdigest()}
    except (OSError,IndexError,ValueError): raise ProcessLookupError() from None


def start(payload):
    site_id=payload.get('siteId')
    if not isinstance(site_id,str) or not SITE_ID.fullmatch(site_id): raise ValueError('Invalid site identifier')
    options={key:payload.get(key) for key in ('files','database','core')}
    if any(type(v) is not bool for v in options.values()) or not any(options.values()):
        raise ValueError('Select at least one scan check')
    private_dir(BASE/'jobs'); lock=BASE/'scan-start.lock'
    if shutil.disk_usage(BASE).free < MIN_FREE:
        raise ValueError('Insufficient private scan storage: at least 1 GiB free is required')
    with lock.open('a') as handle:
        os.chmod(lock,0o600); fcntl.flock(handle,fcntl.LOCK_EX)
        for directory in (BASE/'jobs').iterdir():
            if directory.is_symlink() or not UUID.fullmatch(directory.name): continue
            previous=status(directory.name).get('scan',{})
            if previous.get('status')=='running': raise ValueError('A scan is already running for this local site')
        scan_id=str(uuid.uuid4()); job=private_dir(job_dir(scan_id))
        scan={'id':scan_id,'siteId':site_id,'status':'running','phase':'starting','createdAt':now(),'options':options}
        private_write(job/'scan.json',scan)
        encoded=base64.b64encode(json.dumps({'scanId':scan_id}).encode()).decode()
        with (job/'worker.log').open('xb') as log:
            log_path=job/'worker.log'; log_path.chmod(0o600)
            archive_fd=sealed_archive_fd()
            child=subprocess.Popen([sys.executable,'-I','-S',sys.argv[0],'run',encoded],
                stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,pass_fds=(archive_fd,))
        scan.update(pid=child.pid,**process_identity(child.pid)); private_write(job/'scan.json',scan)
        return {'scan':scan}


def run_scan(scan_id):
    job=job_dir(scan_id)
    # Parent must publish the actual PID before the child writes its first phase;
    # otherwise a fast child could overwrite that PID with the initial metadata.
    deadline=time.monotonic()+10
    while True:
        scan=json.loads((job/'scan.json').read_text())
        if scan.get('pid')==os.getpid(): break
        if time.monotonic()>deadline: raise ValueError('Scan startup handshake failed')
        time.sleep(0.02)
    def phase(name):
        scan['phase']=name; private_write(job/'scan.json',scan)
    try:
        phase('snapshot'); copy_check,manifest=snapshot(ROOT,job/'snapshot'); checks=[copy_check]
        private_json(job/'manifest.json',manifest); root=job/'snapshot'; options=scan['options']
        if options['files']:
            phase('files'); files,before=inspect_files(root); checks.append(files)
            phase('amwscan'); engine=run_engine(root,materialize_vendor()/'amwscan/scanner',job/'engine'); checks.append(engine)
            # Normalize locations against the private snapshot and retain only safe metadata.
            raw_path=job/'engine/amwscan.json'
            if raw_path.exists():
                raw=json.loads(raw_path.read_text()); originals=raw.get('findings',[])
                engine.findings=[]
                for item in originals:
                    if not isinstance(item,dict): continue
                    subject=item.get('subject'); relative=None
                    if isinstance(subject,str):
                        try: relative=Path(subject).relative_to(root).as_posix()
                        except ValueError:
                            if not Path(subject).is_absolute() and '..' not in Path(subject).parts: relative=subject
                    if relative is None:
                        engine.errors.append('Engine finding has an unsupported location'); continue
                    normalized={k:item[k] for k in ('id','kind','severity','status') if isinstance(item.get(k),str)}
                    normalized.update(subject=relative,rule=item.get('rule_id','amwscan-heuristic'))
                    if relative in manifest: normalized['sha256']=manifest[relative]['sha256']
                    evidence=item.get('evidence',{}); line=evidence.get('line') if isinstance(evidence,dict) else None
                    if isinstance(line,(int,str)) and re.fullmatch(r'\d{1,8}',str(line)): normalized['line']=int(line)
                    engine.findings.append(normalized)
                engine.coverage['definitions']=raw.get('signature_indexes',{})
                if engine.errors and engine.status not in ('incomplete','error'): engine.status='incomplete'
            after_check,after=inspect_files(root); consistent=Check('snapshot-consistency')
            consistent.coverage={'changedFiles':compare_manifests(before,after)}
            checks.append(consistent.finish(not consistent.coverage['changedFiles'] and after_check.status!='incomplete'))
        else: checks.extend([Check('files-and-persistence'),Check('amwscan')])
        if options['database']:
            phase('database')
            try:
                config=read_configuration(root)
                checks.extend(audit_database(MysqlExecutor(['mysql','-hdb','-udb','-pdb','--batch','--raw','--skip-column-names','db']),config['prefix']))
            except Exception as error:
                reason=str(error) if isinstance(error,ValueError) else type(error).__name__
                checks.append(Check('database',status='error',errors=['Database check unavailable: '+reason]))
        else: checks.append(Check('database'))
        if options['core']:
            phase('core-checksums')
            try:
                version,locale=core_release(root)
                official=fetch_core_manifest(version,locale); private_json(job/'core-checksums.json',official)
                core=core_checksums(root,official); core.coverage['provenance']=official['provenance']; checks.append(core)
                verified={}
                for name,digest in official['checksums'].items():
                    if name.startswith('wp-content/') or name not in manifest: continue
                    path=Path(name)
                    if path.is_absolute() or '..' in path.parts: continue
                    data=(root/name).read_bytes()
                    if hashlib.md5(data).hexdigest()==digest: verified[name]=hashlib.sha256(data).hexdigest()
                for check in checks:
                    for finding in check.findings:
                        name=finding.get('subject')
                        if isinstance(name,str) and name in verified and verified[name]==finding.get('sha256'): finding['coreVerified']=True
            except Exception as error:
                reason=str(error) if isinstance(error,ValueError) else type(error).__name__
                checks.append(Check('wordpress-core-checksums',status='error',errors=['Official core check unavailable: '+reason]))
        else: checks.append(Check('wordpress-core-checksums'))
        checks.extend([Check('plugin-theme-checksums'),Check('host-persistence')])
        value=report(checks,version=__version__,generatedAt=now(),tools=tooling_metadata()['tools'],
                     note='Findings require review. Skipped or unavailable checks keep overall coverage incomplete. No site PHP was executed; live database queries are individually read-only, not an atomic site snapshot.')
        private_json(job/'report.json',value)
        scan.update(status='completed',phase='complete',completedAt=now())
    except Exception as error:
        scan.update(status='failed',phase='failed',completedAt=now(),error='Scan failed: '+type(error).__name__+'; coverage is incomplete')
    finally:
        # Snapshots include configuration credentials and hundreds of MiB of media.
        # Actions bind retained hashes to current live bytes; the disposable copy
        # is never the recovery backup. Keep reports/manifests/checksums only.
        copied=job/'snapshot'
        if copied.exists() and not copied.is_symlink():
            try: shutil.rmtree(copied)
            except OSError:
                scan['cleanupWarning']='Private snapshot cleanup failed; operator storage review is required'
    private_write(job/'scan.json',scan)
    return status(scan_id)


def chunk(payload):
    if payload.get('planId'):
        from .remediation import backup_chunk
        return backup_chunk(BASE,payload['planId'],payload.get('offset',0),payload.get('length',524288))
    job=job_dir(payload.get('scanId')); name=payload.get('name','report.json')
    if name not in {'report.json','manifest.json','core-checksums.json'}: raise ValueError('Unsupported scan artifact')
    offset,length=payload.get('offset',0),payload.get('length',524288)
    if type(offset) is not int or offset<0 or type(length) is not int or not 1<=length<=524288:
        raise ValueError('Invalid chunk bounds')
    path=job/name
    if path.is_symlink(): raise ValueError('Unsafe scan artifact')
    with path.open('rb') as stream: stream.seek(offset); data=stream.read(length)
    return {'offset':offset,'bytes':len(data),'totalBytes':path.stat().st_size,'data':base64.b64encode(data).decode()}


def dispatch(command,payload):
    if command=='capabilities': return tooling_metadata()
    if command=='start': return start(payload)
    if command=='status': return status(payload.get('scanId'))
    if command=='run': return run_scan(payload.get('scanId'))
    if command=='chunk': return chunk(payload)
    if command=='plan':
        from .remediation import create_plan
        scan=status(payload.get('scanId'))['scan']; job=job_dir(scan['id'])
        if scan['status']!='completed': raise ValueError('Only completed scans can be reviewed')
        core_path=job/'core-checksums.json'; official=json.loads(core_path.read_text()) if core_path.exists() else None
        plan=create_plan(ROOT,BASE,scan['id'],payload.get('operation'),payload.get('path'),scan['report'],official)
        plan['siteId']=scan['siteId']
        return {'plan':plan}
    if command=='apply':
        from .remediation import apply_plan
        return {'action':apply_plan(ROOT,BASE,payload.get('planId'),payload.get('fingerprint'),payload.get('confirmation'),payload.get('verifiedBackupSha256'))}
    if command=='setup-profile':
        from .performance import setup_profile
        return setup_profile(BASE,materialize_vendor())
    if command=='profile':
        from .performance import run_profile
        request={key:value for key,value in payload.items() if key!='siteId'}
        profile=run_profile(ROOT,BASE,request,payload.get('siteUrl'))
        if payload.get('siteId'): profile['siteId']=payload['siteId']
        return {'profile':profile}
    raise ValueError('Unsupported runtime command')


def main():
    os.umask(0o077)
    try:
        if len(sys.argv)!=3: raise ValueError('Expected command and encoded JSON object')
        private_dir(BASE)
        value=dispatch(sys.argv[1],load_payload(sys.argv[2]))
        print(json.dumps(value,ensure_ascii=True))
        return 0
    except Exception as error:
        # Exception messages can include source values/paths. Expose only trusted
        # validation text for ValueError; transport/process failures stay generic.
        message=str(error) if isinstance(error,ValueError) else type(error).__name__+'; runtime operation failed'
        print(json.dumps({'error':message},ensure_ascii=True))
        return 1


if __name__=='__main__': raise SystemExit(main())
