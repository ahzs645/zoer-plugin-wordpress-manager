import hashlib
import re
from pathlib import Path, PurePosixPath
from .model import Check, finding


def core_checksums(root, payload):
    """Compare an independently fetched official WordPress checksum manifest."""
    check = Check("wordpress-core-checksums")
    root = Path(root).resolve()
    manifest = payload.get("checksums") if isinstance(payload, dict) else None
    if not isinstance(manifest, dict) or not manifest:
        check.status = "error"; check.errors = ["Official checksum manifest unavailable"]
        return check
    verified, missing = 0, []
    for name, expected in manifest.items():
        path = PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts or not isinstance(expected, str) or not re.fullmatch(r"[a-f0-9]{32}", expected):
            check.errors.append("Invalid checksum manifest entry")
            continue
        target = root / name
        # WordPress.org manifests include distribution starter themes/plugins. Check only core-owned paths.
        if name.startswith("wp-content/"):
            continue
        if target.is_symlink() or not target.resolve().is_relative_to(root):
            check.errors.append("Symlink or escaped core file: " + name)
            continue
        try:
            data = target.read_bytes()
            if hashlib.md5(data).hexdigest() != expected:
                check.findings.append(finding("modified-core-file", name, data))
            else:
                verified += 1
        except FileNotFoundError:
            missing.append(name)
            check.findings.append(finding("missing-core-file", name))
        except OSError:
            check.errors.append("Unreadable core file: " + name)
    check.coverage = {"verified": verified, "missing": missing,
                      "manifestFiles": len(manifest), "scope": "Official core release files only; plugins/themes and extra files are excluded"}
    return check.finish()
