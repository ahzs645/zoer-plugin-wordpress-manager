"""Separately reviewed, exact-manifest file recovery. Never called by scanning."""
import hashlib
import json
import os
import re
import stat
import time
import urllib.request
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from .mounts import assert_atomic_directory_mount, same_mount

MAX_BACKUP = 64 * 1024 * 1024
MAX_FILES = 20000
ID = re.compile(r'^[a-zA-Z0-9-]{1,80}$')


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _write(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(payload, stream, ensure_ascii=True)


def _safe(root, relative):
    parts = PurePosixPath(relative)
    if parts.is_absolute() or not parts.parts or any(p in ('', '.', '..') for p in parts.parts):
        raise ValueError('Invalid relative file path')
    target = root
    for part in parts.parts:
        target = target / part
        if target.is_symlink():
            raise ValueError('Symlink recovery is unsupported')
    if not target.resolve().is_relative_to(root.resolve()):
        raise ValueError('Recovery path escapes site')
    return target


def _manifest(root, relative):
    target = _safe(root, relative)
    if not target.is_dir():
        raise ValueError('Plugin directory unavailable')
    rows, total = [], 0
    for current, dirs, names in os.walk(target, followlinks=False):
        for name in dirs:
            if (Path(current) / name).is_symlink():
                raise ValueError('Symlink directory is unsupported')
        for name in sorted(names):
            file = Path(current) / name
            info = file.lstat()
            if not stat.S_ISREG(info.st_mode):
                raise ValueError('Non-regular file is unsupported')
            total += info.st_size
            if total > MAX_BACKUP or len(rows) >= MAX_FILES:
                raise ValueError('Recovery backup exceeds supported limit')
            data = file.read_bytes()
            after = file.stat()
            if (info.st_ino, info.st_size, info.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
                raise ValueError('File changed while creating plan')
            rows.append({'path': file.relative_to(root).as_posix(), 'sha256': _digest(data), 'bytes': len(data), 'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid, 'gid': info.st_gid})
    if not rows:
        raise ValueError('Empty plugin cannot be quarantined')
    return sorted(rows, key=lambda item: item['path'])


def _findings(report):
    return [f for check in report.get('checks', []) for f in check.get('findings', []) if isinstance(f, dict)]


def _subject(f):
    value = f.get('subject')
    return value if isinstance(value, str) else ''


def _plan_dir(private, plan_id):
    if not isinstance(plan_id, str) or not ID.fullmatch(plan_id):
        raise ValueError('Invalid plan ID')
    target = Path(private) / 'plans' / plan_id
    if target.is_symlink() or not target.resolve().is_relative_to(Path(private).resolve()):
        raise ValueError('Unsafe private plan path')
    return target


def _fingerprint(plan):
    fields = {key: plan.get(key) for key in ('operation', 'path', 'files', 'replacements')}
    if plan.get('operation') == 'repair-core':
        fields['releaseIdentity'] = plan.get('releaseIdentity')
    return _digest(json.dumps(fields, sort_keys=True).encode())


def _plugin_path(path):
    if not isinstance(path, str) or not re.fullmatch(r'wp-content/plugins/[a-zA-Z0-9][a-zA-Z0-9_.-]{0,100}', path):
        raise ValueError('Select one ordinary plugin directory')
    if path.split('/')[-1].lower().replace('-', '').replace('_', '') in ('zoerconnect', 'zoerwordpressconnect', 'wordpressmanager'):
        raise ValueError('Zoer connection tooling cannot be quarantined')


def _core_path(path):
    root_files = {'index.php', 'license.txt', 'readme.html', 'xmlrpc.php', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-config-sample.php', 'wp-cron.php', 'wp-links-opml.php', 'wp-load.php', 'wp-login.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php'}
    return isinstance(path, str) and (path.startswith(('wp-admin/', 'wp-includes/')) or path in root_files)


def _release_identity(root, version, checksums, findings):
    name = 'wp-includes/version.php'
    expected = checksums.get(name)
    if not isinstance(expected, str) or not re.fullmatch(r'[a-f0-9]{32}', expected):
        raise ValueError('Official release version-file checksum unavailable')
    target = _safe(root, name)
    evidence = [f for f in findings if _subject(f) == name and f.get('rule') in ('missing-core-file', 'modified-core-file')]
    if len(evidence) > 1:
        raise ValueError('Ambiguous scanned core release identity')
    if evidence and evidence[0]['rule'] == 'missing-core-file':
        if target.exists():
            raise ValueError('Core release identity changed since scan')
        baseline = {'path': name, 'sha256': None, 'bytes': 0, 'missing': True}
    else:
        if not target.is_file() or target.stat().st_size > 1024 * 1024:
            raise ValueError('Core release identity unavailable')
        data = target.read_bytes()
        if evidence:
            if _digest(data) != evidence[0].get('sha256'):
                raise ValueError('Core release identity changed since scan')
        elif hashlib.md5(data).hexdigest() != expected:
            raise ValueError('Core release identity changed since scan; run a new scan before repair')
        baseline = {'path': name, 'sha256': _digest(data), 'bytes': len(data)}
    return {'version': version, 'officialVersionMd5': expected, 'versionFile': baseline}


def _verify_release_identity(root, identity, repaired_version=None):
    baseline = repaired_version or identity['versionFile']
    target = _safe(root, 'wp-includes/version.php')
    if baseline.get('missing'):
        if target.exists():
            raise ValueError('Core release identity changed after review; run a new scan')
    elif not target.is_file() or target.stat().st_size != baseline['bytes'] or _digest(target.read_bytes()) != baseline['sha256']:
        raise ValueError('Core release identity changed after review; run a new scan')


def _validate_plan(root, plan):
    operation = plan.get('operation')
    if operation not in ('quarantine', 'repair-core'):
        raise ValueError('Unsupported recovery operation')
    if not isinstance(plan.get('scanId'), str) or not ID.fullmatch(plan['scanId']):
        raise ValueError('Invalid plan scan ID')
    files, replacements = plan.get('files'), plan.get('replacements')
    if not isinstance(files, list) or not 1 <= len(files) <= MAX_FILES or not isinstance(replacements, list):
        raise ValueError('Invalid reviewed file manifest')
    names, total = set(), 0
    if operation == 'quarantine':
        _plugin_path(plan.get('path'))
    elif plan.get('path') is not None:
        raise ValueError('Core repair cannot select a caller path')
    for file in files:
        if not isinstance(file, dict) or set(file) - {'path', 'sha256', 'bytes', 'mode', 'uid', 'gid', 'missing'}:
            raise ValueError('Invalid reviewed file metadata')
        name = file.get('path')
        _safe(root, name)
        if name in names:
            raise ValueError('Duplicate reviewed file')
        names.add(name)
        size = file.get('bytes')
        if type(size) is not int or not 0 <= size <= MAX_BACKUP:
            raise ValueError('Invalid reviewed file size')
        total += size
        if total > MAX_BACKUP:
            raise ValueError('Reviewed backup exceeds supported limit')
        if operation == 'quarantine' and (not name.startswith(plan['path'] + '/') or file.get('missing')):
            raise ValueError('File escapes reviewed plugin scope')
        if operation == 'repair-core' and not _core_path(name):
            raise ValueError('File escapes official core scope')
        if file.get('missing'):
            if file.get('missing') is not True or size != 0 or file.get('sha256') is not None:
                raise ValueError('Invalid missing file baseline')
        elif not isinstance(file.get('sha256'), str) or not re.fullmatch(r'[a-f0-9]{64}', file['sha256']):
            raise ValueError('Invalid reviewed file digest')
        for key, limit in (('mode', 0o7777), ('uid', 2**32-2), ('gid', 2**32-2)):
            if key in file and (type(file[key]) is not int or not 0 <= file[key] <= limit):
                raise ValueError('Invalid reviewed file ownership')
    if operation == 'quarantine' and replacements:
        raise ValueError('Quarantine cannot replace files')
    if operation == 'repair-core':
        identity = plan.get('releaseIdentity')
        if not isinstance(identity, dict) or set(identity) != {'version', 'officialVersionMd5', 'versionFile'} or not isinstance(identity['version'], str) or not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', identity['version']) or not isinstance(identity['officialVersionMd5'], str) or not re.fullmatch(r'[a-f0-9]{32}', identity['officialVersionMd5']):
            raise ValueError('Reviewed core release identity unavailable')
        baseline = identity['versionFile']
        if not isinstance(baseline, dict) or set(baseline) - {'path', 'sha256', 'bytes', 'missing'} or baseline.get('path') != 'wp-includes/version.php' or type(baseline.get('bytes')) is not int or not 0 <= baseline['bytes'] <= 1024 * 1024:
            raise ValueError('Invalid reviewed core version-file baseline')
        if baseline.get('missing'):
            if baseline.get('missing') is not True or baseline['bytes'] != 0 or baseline.get('sha256') is not None:
                raise ValueError('Invalid missing core version-file baseline')
        elif not isinstance(baseline.get('sha256'), str) or not re.fullmatch(r'[a-f0-9]{64}', baseline['sha256']):
            raise ValueError('Invalid reviewed core version-file digest')
        seen, size = set(), 0
        for item in replacements:
            if not isinstance(item, dict) or set(item) != {'path', 'sha256', 'bytes'} or item['path'] not in names or item['path'] in seen or not isinstance(item['sha256'], str) or not re.fullmatch(r'[a-f0-9]{64}', item['sha256']) or type(item['bytes']) is not int or not 0 <= item['bytes'] <= MAX_BACKUP:
                raise ValueError('Invalid trusted replacement manifest')
            seen.add(item['path']); size += item['bytes']
        if seen != names or size > MAX_BACKUP:
            raise ValueError('Trusted replacement scope mismatch')


def _verify_backup(directory, plan):
    with zipfile.ZipFile(directory / 'beforeimages.zip') as archive:
        names = ['manifest.json'] + ['site/' + f['path'] for f in plan['files'] if not f.get('missing')]
        if len(archive.infolist()) != len(names) or set(archive.namelist()) != set(names):
            raise ValueError('Recovery archive scope mismatch')
        metadata_info = archive.getinfo('manifest.json')
        if metadata_info.file_size > 16 * 1024 * 1024:
            raise ValueError('Recovery metadata exceeds supported limit')
        metadata = json.loads(archive.read('manifest.json'))
        if metadata != {'scanId': plan['scanId'], 'operation': plan['operation'], 'files': plan['files']}:
            raise ValueError('Recovery archive manifest mismatch')
        for file in plan['files']:
            if file.get('missing'):
                continue
            info = archive.getinfo('site/' + file['path'])
            if info.file_size != file['bytes'] or _digest(archive.read(info)) != file['sha256']:
                raise ValueError('Recovery archive file verification failed')


def quarantine_capability(root, private):
    """Atomic containment needs private recovery storage on the site's filesystem."""
    root, private = Path(root).resolve(), Path(private).resolve()
    try:
        plugins = _safe(root, 'wp-content/plugins')
        if private.is_relative_to(root):
            return {'quarantineAvailable': False, 'quarantineUnavailableReason': 'Private recovery storage must be outside the webroot.'}
        if not plugins.is_dir() or not private.is_dir():
            return {'quarantineAvailable': False, 'quarantineUnavailableReason': 'Local plugin or private recovery storage is unavailable.'}
        if plugins.stat().st_dev != private.stat().st_dev:
            return {'quarantineAvailable': False, 'quarantineUnavailableReason': 'Atomic quarantine is unavailable: the site and private recovery storage are on different filesystem mounts. One shared parent mount with private recovery storage outside the webroot is required.'}
        if not same_mount(plugins, private):
            return {'quarantineAvailable': False, 'quarantineUnavailableReason': 'Atomic quarantine is unavailable: plugin and private recovery directories must share one exact filesystem mount; separate bind mounts cannot rename atomically.'}
        if not os.access(plugins, os.W_OK | os.X_OK) or not os.access(private, os.W_OK | os.X_OK):
            return {'quarantineAvailable': False, 'quarantineUnavailableReason': 'The local runtime cannot rename plugin directories into private recovery storage.'}
        return {'quarantineAvailable': True}
    except (OSError, ValueError):
        return {'quarantineAvailable': False, 'quarantineUnavailableReason': 'Unable to verify local recovery filesystem access.'}


def create_plan(root, private, scan_id, operation, path=None, report=None, core_manifest=None, *, fetch=None):
    root, private = Path(root).resolve(), Path(private).resolve()
    if private.is_relative_to(root):
        raise ValueError('Recovery storage must be outside webroot')
    if not isinstance(scan_id, str) or not ID.fullmatch(scan_id):
        raise ValueError('Invalid scan ID')
    findings = _findings(report or {})
    replacements = {}
    release_identity = None
    if operation == 'quarantine':
        capability = quarantine_capability(root, private)
        if not capability['quarantineAvailable']:
            raise ValueError(capability['quarantineUnavailableReason'])
        _plugin_path(path)
        destination_parent=private/'plans' if (private/'plans').exists() else private
        assert_atomic_directory_mount(_safe(root,path),destination_parent)
        _plugin_path(path)
        evidence = [f for f in findings if _subject(f).startswith(path + '/') and not f.get('coreVerified')]
        if not evidence:
            raise ValueError('Selected plugin has no findings in this scan')
        files = _manifest(root, path)
        hashes = {item['path']: item['sha256'] for item in files}
        if not any(f.get('sha256') == hashes.get(_subject(f)) for f in evidence):
            raise ValueError('Scan evidence no longer matches selected plugin bytes')
    elif operation == 'repair-core':
        manifest = core_manifest or {}
        checksums = manifest.get('checksums', {})
        version = manifest.get('version', manifest.get('_version'))
        if not isinstance(version, str) or not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', version) or not isinstance(checksums, dict):
            raise ValueError('Verified release metadata unavailable')
        release_identity = _release_identity(root, version, checksums, findings)
        candidates = [f for f in findings if f.get('rule') in ('missing-core-file', 'modified-core-file')]
        if not candidates:
            raise ValueError('This scan has no missing or modified core files')
        files = []
        for finding in candidates:
            name = _subject(finding)
            if not _core_path(name) or name not in checksums:
                raise ValueError('Invalid core repair candidate')
            target = _safe(root, name)
            missing = finding['rule'] == 'missing-core-file'
            if missing:
                if target.exists():
                    raise ValueError('Missing core file has changed since scan')
                files.append({'path': name, 'sha256': None, 'bytes': 0, 'missing': True})
            else:
                if not target.is_file() or target.stat().st_size > MAX_BACKUP:
                    raise ValueError('Core candidate unavailable or too large')
                data = target.read_bytes()
                if _digest(data) != finding.get('sha256'):
                    raise ValueError('Core file changed since scan')
                info = target.stat()
                files.append({'path': name, 'sha256': _digest(data), 'bytes': len(data), 'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid, 'gid': info.st_gid})
        files = sorted({item['path']: item for item in files}.values(), key=lambda item: item['path'])
        if len(files) > MAX_FILES or sum(f['bytes'] for f in files) > MAX_BACKUP:
            raise ValueError('Core recovery backup exceeds supported limit')
        download = fetch or _download_release
        release = download('https://wordpress.org/wordpress-' + version + '.zip')
        from io import BytesIO
        with zipfile.ZipFile(BytesIO(release)) as archive:
            for file in files:
                data = archive.read('wordpress/' + file['path'])
                if len(data) > MAX_BACKUP or not re.fullmatch(r'[a-f0-9]{32}', str(checksums[file['path']])) or hashlib.md5(data).hexdigest() != checksums[file['path']]:
                    raise ValueError('Official release checksum mismatch')
                replacements[file['path']] = data
    else:
        raise ValueError('Unsupported recovery operation')
    if release_identity:
        _verify_release_identity(root, release_identity)
    plan_id = str(uuid.uuid4())
    directory = _plan_dir(private, plan_id)
    directory.mkdir(parents=True, mode=0o700)
    os.chmod(directory, 0o700)
    backup = directory / 'beforeimages.zip'
    with zipfile.ZipFile(backup, 'x', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json', json.dumps({'scanId': scan_id, 'operation': operation, 'files': files}))
        for file in files:
            if not file.get('missing'):
                data = _safe(root, file['path']).read_bytes()
                if _digest(data) != file['sha256']:
                    raise ValueError('File changed before backup')
                archive.writestr('site/' + file['path'], data)
    os.chmod(backup, 0o600)
    if backup.stat().st_size > MAX_BACKUP:
        raise ValueError('Compressed backup exceeds supported limit')
    replacement_rows = []
    if replacements:
        with zipfile.ZipFile(directory / 'replacements.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
            for name, data in replacements.items():
                archive.writestr(name, data)
                replacement_rows.append({'path': name, 'sha256': _digest(data), 'bytes': len(data)})
        os.chmod(directory / 'replacements.zip', 0o600)
    fingerprint = _fingerprint({'operation': operation, 'path': path, 'files': files, 'replacements': replacement_rows, 'releaseIdentity': release_identity})
    backup_sha = _digest(backup.read_bytes())
    plan = {'id': plan_id, 'scanId': scan_id, 'operation': operation, 'path': path, 'files': files, 'replacements': replacement_rows, 'fingerprint': fingerprint, 'confirmation': 'QUARANTINE ' + path.split('/')[-1] if operation == 'quarantine' else 'REPAIR CORE', 'createdAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'summary': ('Quarantine plugin directory ' + path) if operation == 'quarantine' else 'Restore ' + str(len(files)) + ' official core files', 'warnings': ['Site behavior can change. Recovery backup must be verified by the host before applying.', 'Generic detections require review; findings alone do not establish malware.'], 'backup': {'sha256': backup_sha, 'bytes': backup.stat().st_size}, 'backupSha256': backup_sha, 'backupBytes': backup.stat().st_size}
    if release_identity:
        plan['releaseIdentity'] = release_identity
    _write(directory / 'plan.json', plan)
    return plan


def _download_release(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'Zoer-WordPress-Security/0.2'})
    with urllib.request.urlopen(request, timeout=90) as response:
        if response.url != url:
            raise ValueError('Unexpected official release redirect')
        payload = response.read(128 * 1024 * 1024 + 1)
        if len(payload) > 128 * 1024 * 1024:
            raise ValueError('Official release exceeds supported limit')
        return payload


def backup_chunk(private, plan_id, offset, length=524288):
    import base64
    if type(offset) is not int or offset < 0 or type(length) is not int or not 1 <= length <= 1048576:
        raise ValueError('Invalid backup range')
    directory = _plan_dir(private, plan_id)
    plan = json.loads((directory / 'plan.json').read_text())
    with (directory / 'beforeimages.zip').open('rb') as stream:
        stream.seek(offset)
        data = stream.read(length)
    return {'offset': offset, 'data': base64.b64encode(data).decode(), 'bytes': len(data), 'totalBytes': plan['backupBytes'], 'sha256': plan['backupSha256']}


def apply_plan(root, private, plan_id, fingerprint, confirmation, verified_backup_sha256):
    root = Path(root).resolve()
    directory = _plan_dir(private, plan_id)
    plan = json.loads((directory / 'plan.json').read_text())
    _validate_plan(root, plan)
    expected_confirmation = 'QUARANTINE ' + plan['path'].split('/')[-1] if plan['operation'] == 'quarantine' else 'REPAIR CORE'
    if fingerprint != plan['fingerprint'] or fingerprint != _fingerprint(plan) or confirmation != plan['confirmation'] or confirmation != expected_confirmation:
        raise ValueError('Plan review confirmation or fingerprint does not match')
    if verified_backup_sha256 != plan['backupSha256'] or _digest((directory / 'beforeimages.zip').read_bytes()) != verified_backup_sha256:
        raise ValueError('Host verified recovery backup required')
    _verify_backup(directory, plan)
    if os.path.lexists(directory/'apply-started.json'):
        raise FileExistsError('Recovery action already started; inspect its existing receipt')
    if plan['operation'] == 'quarantine':
        assert_atomic_directory_mount(_safe(root,plan['path']),directory)
    if plan['operation'] == 'repair-core':
        _verify_release_identity(root, plan['releaseIdentity'])
    # Exclusive marker prevents replay; failed attempts leave an explicit private receipt.
    marker = directory / 'apply-started.json'
    _write(marker, {'createdAt': time.time()})
    action = {'id': str(uuid.uuid4()), 'planId': plan_id, 'scanId': plan['scanId'], 'operation': plan['operation'], 'createdAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'summary': ('Quarantine plugin directory ' + plan['path']) if plan['operation'] == 'quarantine' else 'Restore ' + str(len(plan['files'])) + ' official core files', 'recoveryPath': str(directory), 'backupSha256': verified_backup_sha256}
    try:
        if plan['operation'] == 'quarantine':
            if _manifest(root, plan['path']) != plan['files']:
                raise ValueError('Live plugin manifest changed; create a new plan')
            original = _safe(root, plan['path'])
            assert_atomic_directory_mount(original,directory)
            os.rename(original, directory / 'original-directory')
            if original.exists() or _manifest(directory, 'original-directory') != [dict(file, path='original-directory/' + file['path'].split('/', 3)[-1]) for file in plan['files']]:
                raise ValueError('Quarantine verification failed')
        else:
            for file in plan['files']:
                target = _safe(root, file['path'])
                if file.get('missing'):
                    if target.exists():
                        raise ValueError('Missing core baseline changed')
                elif not target.is_file() or _digest(target.read_bytes()) != file['sha256']:
                    raise ValueError('Core baseline changed; create a new plan')
            expected = {item['path']: item for item in plan['replacements']}
            with zipfile.ZipFile(directory / 'replacements.zip') as archive:
                if len(archive.infolist()) != len(expected) or set(archive.namelist()) != set(expected):
                    raise ValueError('Trusted replacement archive scope changed')
                if any(archive.getinfo(name).file_size != item['bytes'] for name, item in expected.items()):
                    raise ValueError('Trusted replacement archive sizes changed')
                replacement_data = {name: archive.read(name) for name in expected}
            if any(_digest(data) != expected[name]['sha256'] for name, data in replacement_data.items()):
                raise ValueError('Trusted replacements changed')
            repaired_version = None
            for file in plan['files']:
                _verify_release_identity(root, plan['releaseIdentity'], repaired_version)
                target = _safe(root, file['path'])
                target.parent.mkdir(parents=True, exist_ok=True)
                # Existing core beforeimages already preserved in verified host backup.
                temp = target.with_name('.zoer-core-' + uuid.uuid4().hex)
                fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, file.get('mode', 0o644))
                with os.fdopen(fd, 'wb') as stream:
                    stream.write(replacement_data[file['path']]); stream.flush(); os.fsync(stream.fileno())
                info = target.stat() if target.exists() else target.parent.stat()
                if os.geteuid() == 0:
                    os.chown(temp, file.get('uid', info.st_uid), file.get('gid', info.st_gid))
                # Recheck immediately before replacement; missing creation is exclusive.
                if file.get('missing'):
                    os.link(temp, target); temp.unlink()
                else:
                    if _digest(target.read_bytes()) != file['sha256']:
                        temp.unlink(); raise ValueError('Core changed during apply')
                    os.replace(temp, target)
                if _digest(target.read_bytes()) != expected[file['path']]['sha256']:
                    raise ValueError('Core repair readback failed')
                if file['path'] == 'wp-includes/version.php':
                    repaired_version = expected[file['path']]
            _verify_release_identity(root, plan['releaseIdentity'], repaired_version)
        action['status'] = 'completed'
    except Exception as exc:
        action['status'] = 'failed'
        action['error'] = str(exc)
    _write(directory / 'action.json', action)
    return action
