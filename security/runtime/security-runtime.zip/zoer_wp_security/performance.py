"""Explicit opt-in WordPress profiling, isolated from read-only security scans."""
import hashlib
import json
import math
import os
import re
import shutil
import signal
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from urllib.parse import unquote, urlsplit, urlunsplit

VERSION = '2.1.5'
WARNING = 'Profiling loads and executes this local site’s WordPress, plugins and theme. It can perform normal site-side effects; run it only when you want to test this site.'
QUERIES_REASON = 'Query profiling requires profile-command 3.x and WP-CLI 3.x; this compatible package provides stage and hook profiling with database time and query-count metrics.'
LOADER = r'''<?php
spl_autoload_register(static function ($class) {
    $prefix = 'WP_CLI\\Profile\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) { return; }
    $name = substr($class, strlen($prefix));
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $name)) { return; }
    $file = __DIR__ . '/src/' . $name . '.php';
    if (is_file($file)) { require_once $file; }
});
require_once __DIR__ . '/profile-command.php';
'''


SOURCE_HASHES = {'LICENSE.md': '17af76a1d77de4abb3c6782f1a2b34cfbaa16bcde02d65f0ef0cc925d418c7b0',
 'composer.json': 'd5bfdc82256c37adae56c76aa7bf191662952909345d8ab0b7d36c4cedd8209a',
 'profile-command.php': '24e9ce43bb3af8e19361f49cfc5a042b43b63b2d601cd7aca5ee894ae405ba2c',
 'src/Command.php': '44f24e55d7317d1473a93c5c4267b3a65566831c733eedd9f5b14175d2a6d4cb',
 'src/Formatter.php': '9de2f4c6dd2023a277ff3640be559e5e2fd74c2d43b74d9e45e6d685312ac258',
 'src/Logger.php': 'fca7b108e4d6cfc3926dc7caf3616b166d08a4f20472db0267e033add38e54d7',
 'src/Profiler.php': '5375bd60ba2386eec8b132dddc1a2d3877aee79212e0c867a53d28c135dd543f'}

def setup_profile(private, vendor_root):
    private, source = Path(private).resolve(), Path(vendor_root).resolve() / 'profile-command'
    if not source.is_dir():
        raise ValueError('Bundled compatible profiling package unavailable')
    destination = private / 'performance' / 'profile-command-2.1.5'
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if destination.exists():
        if destination.is_symlink():
            raise ValueError('Unsafe profiling tooling path')
        for name, digest in _expected_hashes().items():
            path = destination / name
            if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError('Profiling tooling has changed; reinstall reviewed runtime')
        return _capabilities()
    temp = destination.with_name('.profile-' + uuid.uuid4().hex)
    temp.mkdir(mode=0o700)
    names = ['composer.json', 'LICENSE.md', 'profile-command.php'] + ['src/' + name for name in ('Command.php', 'Profiler.php', 'Logger.php', 'Formatter.php')]
    for name in names:
        file = source / name
        if file.is_symlink() or not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest() != SOURCE_HASHES[name]:
            raise ValueError('Unexpected profiling package input')
        target = temp / name
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        shutil.copyfile(file, target)
        os.chmod(target, 0o600)
    (temp / 'loader.php').write_text(LOADER)
    (temp / 'wp-cli.yml').write_text('{}\n')
    for name in ('loader.php', 'wp-cli.yml'):
        os.chmod(temp / name, 0o600)
    hashes = {name: hashlib.sha256((temp / name).read_bytes()).hexdigest() for name in names + ['loader.php', 'wp-cli.yml']}
    (temp / 'installed.json').write_text(json.dumps({'version': VERSION, 'files': hashes}))
    os.chmod(temp / 'installed.json', 0o600)
    os.rename(temp, destination)
    return _capabilities()


def _expected_hashes():
    return dict(SOURCE_HASHES, **{'loader.php': hashlib.sha256(LOADER.encode()).hexdigest(), 'wp-cli.yml': hashlib.sha256(b'{}\n').hexdigest()})


def _capabilities():
    return {'profilingAvailable': True, 'profilingSetupRequired': False, 'profileModes': ['stage', 'hook'], 'profileQueriesReason': QUERIES_REASON, 'profileCommandVersion': VERSION}


def _url(site_url, path):
    if not isinstance(site_url, str):
        raise ValueError('Invalid host-provided site URL')
    base = urlsplit(site_url)
    if base.scheme not in ('http', 'https') or not base.hostname or base.username or base.password or base.query or base.fragment:
        raise ValueError('Invalid host-provided site URL')
    path = '/' if path in (None, '') else path
    if not isinstance(path, str) or len(path) > 512 or not path.startswith('/') or path.startswith('//') or '\\' in path or '#' in path or '?' in path or any(ord(c) < 32 for c in path):
        raise ValueError('Use one same-site URL path without a query or fragment')
    decoded = unquote(path)
    if decoded.startswith('//') or '\\' in decoded or any(part == '..' for part in decoded.split('/')) or any(ord(c) < 32 for c in decoded):
        raise ValueError('Invalid local URL path')
    return urlunsplit((base.scheme, base.netloc, path, '', ''))


def profile_command(root, private, request, site_url):
    if not isinstance(request, dict) or set(request) - {'mode', 'stage', 'hook', 'urlPath', 'siteUrl'}:
        raise ValueError('Unsupported profiling options')
    mode = request.get('mode', 'stage')
    if mode not in ('stage', 'hook'):
        raise ValueError(QUERIES_REASON if mode == 'queries' else 'Unsupported profiling mode')
    if Path(private).resolve().is_relative_to(Path(root).resolve()):
        raise ValueError('Profiling tooling must be outside webroot')
    directory = Path(private).resolve() / 'performance' / 'profile-command-2.1.5'
    if directory.is_symlink() or not (directory / 'installed.json').is_file():
        raise ValueError('Set up profiling tooling first')
    hashes = _expected_hashes()
    for name, digest in hashes.items():
        path = directory / name
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('Installed profiling tooling changed')
    if (directory / 'wp-cli.yml').read_bytes() != b'{}\n':
        raise ValueError('Profiling configuration changed')
    args = ['wp', '--path=' + str(Path(root).resolve()), '--skip-packages', '--no-color', '--require=' + str(directory / 'loader.php'), '--url=' + _url(site_url, request.get('urlPath')), 'profile', mode]
    if mode == 'stage':
        stage = request.get('stage')
        if stage not in (None, '', 'bootstrap', 'main_query', 'template'):
            raise ValueError('Unsupported WordPress stage')
        if stage:
            if stage not in ('bootstrap', 'main_query', 'template'):
                raise ValueError('Unsupported WordPress stage')
            args.append(stage)
        if request.get('hook'):
            raise ValueError('Hook selector does not apply to stage mode')
        fields = ('hook' if stage else 'stage') + ',time,query_time,query_count,cache_hits,cache_misses,cache_ratio,request_time,request_count'
    else:
        hook = request.get('hook')
        if not isinstance(hook, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_:/.-]{0,99}', hook):
            raise ValueError('Select one WordPress hook')
        if request.get('stage'):
            raise ValueError('Stage selector does not apply to hook mode')
        args.append(hook)
        # Callback location/arguments and SQL text are deliberately excluded.
        fields = 'callback,time,query_time,query_count,cache_hits,cache_misses,cache_ratio,request_time,request_count'
    args += ['--format=json', '--fields=' + fields]
    environment = {key: value for key, value in os.environ.items() if not key.startswith('WP_CLI_')}
    environment.update({'WP_CLI_CONFIG_PATH': '/dev/null', 'WP_CLI_PACKAGES_DIR': str(directory / 'empty-packages'), 'WP_CLI_CACHE_DIR': str(directory / 'cache'), 'WP_CLI_PHP_ARGS': ''})
    return args, directory, environment


def _bounded_process(args, cwd, env, timeout=180):
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        process = subprocess.Popen(args, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
        deadline = time.monotonic() + timeout
        failure = None
        while process.poll() is None:
            if time.monotonic() > deadline:
                failure = 'Profiling timed out'
            if os.fstat(out.fileno()).st_size > 2 * 1024 * 1024 or os.fstat(err.fileno()).st_size > 128 * 1024:
                failure = 'Profiling output exceeded limit'
            if failure:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(); break
            time.sleep(0.1)
        out.seek(0); err.seek(0)
        stdout, stderr = out.read(2 * 1024 * 1024 + 1), err.read(128 * 1024 + 1)
        if len(stdout) > 2 * 1024 * 1024 or len(stderr) > 128 * 1024:
            failure = 'Profiling output exceeded limit'
        return process.returncode, stdout, stderr, failure


def run_profile(root, private, request, site_url, *, executor=None):
    args, directory, environment = profile_command(root, private, request, site_url)
    runner = executor or _bounded_process
    created = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    profile = {'id': str(uuid.uuid4()), 'mode': request.get('mode', 'stage'), 'createdAt': created, 'status': 'failed', 'rows': [], 'summary': {}, 'tools': {'profileCommandVersion': VERSION}, 'warning': WARNING}
    code, stdout, stderr, failure = runner(args, directory, environment)
    if failure or code != 0:
        profile['error'] = failure or 'WP-CLI profiling failed (exit ' + str(code) + ')'
        # Site-controlled errors can include credentials or source: retain hashes, not raw text.
        profile['diagnosticSha256'] = hashlib.sha256(stdout + b'\n' + stderr).hexdigest()
        return profile
    if stderr:
        profile['stderrPresent'] = True
        profile['diagnosticSha256'] = hashlib.sha256(stderr).hexdigest()
    try:
        rows = json.loads(stdout)
        if not isinstance(rows, list) or len(rows) > 5000 or not all(isinstance(row, dict) for row in rows):
            raise ValueError('Unsupported profile response')
        allowed = {'stage', 'hook', 'callback', 'time', 'query_time', 'query_count', 'cache_hits', 'cache_misses', 'cache_ratio', 'request_time', 'request_count'}
        normalized = []
        for row in rows:
            item = {}
            for key, value in row.items():
                if key in allowed and isinstance(value, (str, int, float)) and not isinstance(value, bool):
                    if isinstance(value, float) and not math.isfinite(value):
                        raise ValueError('Non-finite profiling metric')
                    item[key] = value[:512] if isinstance(value, str) else value
            normalized.append(item)
        def number(value):
            try:
                return float(str(value).rstrip('s%'))
            except (ValueError, TypeError):
                return 0
        profile.update(status='completed', rows=normalized, summary={'totalTime': sum(number(row.get('time')) for row in normalized), 'queryTime': sum(number(row.get('query_time')) for row in normalized), 'queryCount': sum(number(row.get('query_count')) for row in normalized), 'rowCount': len(normalized)})
    except (ValueError, TypeError, UnicodeError):
        profile['error'] = 'WP-CLI produced an invalid or contaminated JSON profile response'
        profile['diagnosticSha256'] = hashlib.sha256(stdout + b'\n' + stderr).hexdigest()
    return profile
